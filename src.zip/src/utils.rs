use crate::shapes::{Brick};

pub fn rotate_clockwise(game_space: &mut Vec<Vec<Option<Brick>>>) {
    let rows = game_space.len();
    let cols = game_space[0].len();

    let mut min_row = rows;
    let mut min_col = cols;
    let mut max_row = 0;
    let mut max_col = 0;

    for row in 0..rows {
        for col in 0..cols {
            if let Some(brick) = &game_space[row][col] {
                if brick.moving {
                    min_row = min_row.min(row);
                    min_col = min_col.min(col);
                    max_row = max_row.max(row);
                    max_col = max_col.max(col);
                }
            }
        }
    }

    if min_row > max_row || min_col > max_col {
        return;
    }

    let piece_height = max_row - min_row + 1;
    let piece_width = max_col - min_col + 1;
    let size = piece_height.max(piece_width);

    // 3. Create a temporary matrix to hold the piece
    let mut piece_matrix = vec![vec![None; size]; size];

    for row in 0..size {
        for col in 0..size {
            let game_row = min_row + row;
            let game_col = min_col + col;

            if game_row < rows && game_col < cols {
                if let Some(brick) = &game_space[game_row][game_col] {
                    if brick.moving {
                        piece_matrix[row][col] = game_space[game_row][game_col].clone();
                    }
                }
            }
        }
    }

    let mut rotated = vec![vec![None; size]; size];
    for i in 0..size {
        for j in 0..size {
            rotated[j][size - 1 - i] = piece_matrix[i][j].clone();
        }
    }

    let mut can_rotate = true;

    for row in 0..size {
        for col in 0..size {
            if rotated[row][col].is_some() {
                let game_row = min_row + row;
                let game_col = min_col + col;

                // Check bounds
                if game_row >= rows || game_col >= cols || game_row < 0 || game_col < 0 {
                    can_rotate = false;
                    break;
                }

                if let Some(brick) = &game_space[game_row][game_col] {
                    if !brick.moving {
                        can_rotate = false;
                        break;
                    }
                }
            }
        }
        if !can_rotate {
            break;
        }
    }

    if can_rotate {
        for row in 0..rows {
            for col in 0..cols {
                if let Some(brick) = &game_space[row][col] {
                    if brick.moving {
                        game_space[row][col] = None;
                    }
                }
            }
        }

        for row in 0..size {
            for col in 0..size {
                if let Some(brick) = &rotated[row][col] {
                    let game_row = min_row + row;
                    let game_col = min_col + col;

                    if game_row < rows && game_col < cols {
                        game_space[game_row][game_col] = rotated[row][col].clone();
                    }
                }
            }
        }
    }
}


pub fn rotate_counterclockwise(game_space: &mut Vec<Vec<Option<Brick>>>) {
    // 1. Identify the bounds of the current moving piece
    let rows = game_space.len();
    let cols = game_space[0].len();

    let mut min_row = rows;
    let mut min_col = cols;
    let mut max_row = 0;
    let mut max_col = 0;

    for row in 0..rows {
        for col in 0..cols {
            if let Some(brick) = &game_space[row][col] {
                if brick.moving {
                    min_row = min_row.min(row);
                    min_col = min_col.min(col);
                    max_row = max_row.max(row);
                    max_col = max_col.max(col);
                }
            }
        }
    }

    if min_row > max_row || min_col > max_col {
        return;
    }

    let piece_height = max_row - min_row + 1;
    let piece_width = max_col - min_col + 1;
    let size = piece_height.max(piece_width);

    let mut piece_matrix = vec![vec![None; size]; size];

    for row in 0..size {
        for col in 0..size {
            let game_row = min_row + row;
            let game_col = min_col + col;

            if game_row < rows && game_col < cols {
                if let Some(brick) = &game_space[game_row][game_col] {
                    if brick.moving {
                        piece_matrix[row][col] = game_space[game_row][game_col].clone();
                    }
                }
            }
        }
    }

    let mut rotated = vec![vec![None; size]; size];
    for i in 0..size {
        for j in 0..size {
            rotated[size - 1 - j][i] = piece_matrix[i][j].clone();
        }
    }

    let mut can_rotate = true;

    for row in 0..size {
        for col in 0..size {
            if rotated[row][col].is_some() {
                let game_row = min_row + row;
                let game_col = min_col + col;

                // Check bounds
                if game_row >= rows || game_col >= cols || game_row < 0 || game_col < 0 {
                    can_rotate = false;
                    break;
                }

                if let Some(brick) = &game_space[game_row][game_col] {
                    if !brick.moving {
                        can_rotate = false;
                        break;
                    }
                }
            }
        }
        if !can_rotate {
            break;
        }
    }

    if can_rotate {
        for row in 0..rows {
            for col in 0..cols {
                if let Some(brick) = &game_space[row][col] {
                    if brick.moving {
                        game_space[row][col] = None;
                    }
                }
            }
        }

        for row in 0..size {
            for col in 0..size {
                if let Some(brick) = &rotated[row][col] {
                    let game_row = min_row + row;
                    let game_col = min_col + col;

                    if game_row < rows && game_col < cols {
                        game_space[game_row][game_col] = rotated[row][col].clone();
                    }
                }
            }
        }
    }
}